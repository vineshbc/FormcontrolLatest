export const newFont = {
  'Algerian': ['Algerian'],
  'Arial': [
    'Arial',
    'Arial Bold',
    'Arial Bold Italic',
    'Arial Black',
    'Arial Black Italic',
    'Arial Narrow',
    'Arial Narrow Bold',
    'Arial Narrow Bold Italic',
    'Arial Narrow Italic'
  ],
  'Bahnschrift': [
    'Bahnschrift',
    'Bahnschrift Condensed',
    'Bahnschrift Light',
    'Bahnschrift Light Condensed',
    'Bahnschrift Light SemiCondensed',
    'Bahnschrift SemiBold',
    'Bahnschrift SemiBold Condensed',
    'Bahnschrift SemiBold SemiCondensed',
    'Bahnschrift SemiCondensed',
    'Bahnschrift SemiLight',
    'Bahnschrift SemiLight Condensed',
    'Bahnschrift SemiLight SemiCondensed'
  ]
}
